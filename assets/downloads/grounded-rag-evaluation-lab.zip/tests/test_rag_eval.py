from __future__ import annotations

import json
import math
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from rag_eval import (  # noqa: E402
    BM25Index,
    Document,
    EvalCase,
    ParsedAnswer,
    SearchHit,
    cosine_similarity,
    evaluate_answer,
    load_dataset,
    parse_answer,
    reciprocal_rank_fusion,
    retrieval_metrics,
    stable_json_sha256,
    verify_replay,
    write_json,
)


class RagEvalTests(unittest.TestCase):
    def test_frozen_dataset_contract(self) -> None:
        documents, cases = load_dataset(
            ROOT / "data" / "corpus.json",
            ROOT / "data" / "eval.json",
        )
        self.assertEqual(len(documents), 24)
        self.assertEqual(len(cases), 24)
        self.assertEqual(sum(case.answerable for case in cases), 18)
        self.assertEqual(sum(not case.answerable for case in cases), 6)

    def test_bm25_ranks_exact_api_policy_first(self) -> None:
        documents, _ = load_dataset(
            ROOT / "data" / "corpus.json",
            ROOT / "data" / "eval.json",
        )
        hits = BM25Index(documents).search(
            "standard API requests per minute per workspace",
            top_k=4,
        )
        self.assertEqual(hits[0].doc_id, "NS-009")

    def test_cosine_similarity_and_dimension_validation(self) -> None:
        self.assertAlmostEqual(cosine_similarity([1.0, 0.0], [1.0, 0.0]), 1.0)
        self.assertAlmostEqual(cosine_similarity([1.0, 0.0], [0.0, 1.0]), 0.0)
        with self.assertRaisesRegex(ValueError, "dimension mismatch"):
            cosine_similarity([1.0], [1.0, 2.0])

    def test_rrf_combines_rankings_with_deterministic_ties(self) -> None:
        left = [SearchHit("A", 9.0), SearchHit("B", 8.0), SearchHit("C", 7.0)]
        right = [SearchHit("B", 9.0), SearchHit("A", 8.0), SearchHit("C", 7.0)]
        hits = reciprocal_rank_fusion([left, right], top_k=3, rank_constant=60)
        self.assertEqual([hit.doc_id for hit in hits], ["A", "B", "C"])

    def test_parse_answer_enforces_schema_and_context(self) -> None:
        parsed = parse_answer(
            json.dumps(
                {"answer": "Fact.", "citations": ["NS-001"], "abstain": False}
            ),
            ["NS-001", "NS-002"],
        )
        self.assertEqual(parsed, ParsedAnswer("Fact.", ["NS-001"], False))
        with self.assertRaisesRegex(ValueError, "not present"):
            parse_answer(
                json.dumps(
                    {"answer": "Fact.", "citations": ["NS-999"], "abstain": False}
                ),
                ["NS-001"],
            )
        with self.assertRaisesRegex(ValueError, "requires"):
            parse_answer(
                json.dumps(
                    {"answer": "Maybe", "citations": [], "abstain": True}
                ),
                ["NS-001"],
            )

    def test_answer_metrics_separate_answer_citation_and_grounding(self) -> None:
        document = Document(
            "NS-001",
            "Recovery",
            "Canonical fact: Recovery takes 24 hours.",
        )
        case = EvalCase(
            "Q-001",
            "How long?",
            True,
            "Recovery takes 24 hours.",
            ["NS-001"],
        )
        evaluation = evaluate_answer(
            case,
            ParsedAnswer("Recovery takes 24 hours.", ["NS-001"], False),
            {document.id: document},
            None,
        )
        self.assertTrue(evaluation["answer_exact"])
        self.assertEqual(evaluation["citation_precision"], 1.0)
        self.assertEqual(evaluation["citation_recall"], 1.0)
        self.assertTrue(evaluation["grounded"])
        self.assertEqual(evaluation["failure_types"], [])
        self.assertEqual(evaluation["release_decision"], "release_answer")

    def test_release_gate_rejects_unsupported_answer_without_replacement(self) -> None:
        document = Document(
            "NS-001",
            "Recovery",
            "Canonical fact: Recovery takes 24 hours.",
        )
        case = EvalCase(
            "Q-001",
            "How long?",
            True,
            "Recovery takes 24 hours.",
            ["NS-001"],
        )
        evaluation = evaluate_answer(
            case,
            ParsedAnswer("Recovery takes 12 hours.", ["NS-001"], False),
            {document.id: document},
            None,
        )
        self.assertEqual(evaluation["release_decision"], "reject")
        self.assertIn("answer", evaluation["failure_types"])
        self.assertIn("grounding", evaluation["failure_types"])

    def test_retrieval_metrics_report_miss_ids(self) -> None:
        cases = [EvalCase("Q", "query", True, "answer", ["D2"])]
        metrics = retrieval_metrics(
            cases,
            {"Q": [SearchHit("D1", 1.0), SearchHit("D2", 0.5)]},
            top_k=1,
        )
        self.assertEqual(metrics["recall_at_1"], 0.0)
        self.assertEqual(metrics["mrr_at_1"], 0.0)
        self.assertEqual(metrics["miss_question_ids"], ["Q"])

    def test_replay_ignores_timestamps_and_latency_but_not_answers(self) -> None:
        def run(timestamp: str, latency: float, answer: str) -> dict:
            return {
                "started_at_utc": timestamp,
                "dataset": {"hash": "fixed"},
                "configuration": {"top_k": 4},
                "models": {"generation": {"digest": "fixed"}},
                "retrieval_summary": {"hybrid": {"recall_at_4": 1.0}},
                "answer_summary": {"answer_exact_accuracy": 1.0},
                "cases": [
                    {
                        "id": "Q",
                        "rankings": {
                            "lexical": [{"doc_id": "D", "score": 1.0}],
                            "dense": [{"doc_id": "D", "score": 0.9}],
                            "hybrid": [{"doc_id": "D", "score": 0.03}],
                        },
                        "generation": {"response": answer, "wall_duration_ms": latency},
                        "parsed_answer": {"answer": answer},
                        "released_output": {"answer": answer},
                        "validation_error": None,
                        "evaluation": {"answer_exact": True},
                    }
                ],
            }

        first = run("first", 100.0, "same")
        second = run("second", 900.0, "same")
        self.assertTrue(verify_replay(first, second)["exact_match"])
        changed = run("second", 900.0, "different")
        self.assertFalse(verify_replay(first, changed)["exact_match"])

    def test_json_writer_rejects_nan(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(ValueError, "Out of range float values"):
                write_json(Path(directory) / "bad.json", {"value": math.nan})

    def test_stable_hash_is_key_order_independent(self) -> None:
        self.assertEqual(
            stable_json_sha256({"a": 1, "b": 2}),
            stable_json_sha256({"b": 2, "a": 1}),
        )


if __name__ == "__main__":
    unittest.main()
