# Grounded RAG Evaluation Lab

A small, reproducible local benchmark for the path:

`query -> lexical/dense/hybrid retrieval -> cited answer or abstention -> stage metrics -> exact replay`

The project measures retrieval separately from grounded answering. It never retries a
model call and never substitutes a synthetic response for a failed output. The first
ungated diagnostic is preserved as `artifacts/diagnostic_v1.json`; it motivated the
release gate without changing the frozen inputs or generation prompt.

## Evaluation contract

- 24 hand-authored English operations documents
- 24 frozen questions: 18 answerable and 6 deliberately unanswerable
- lexical baseline: a dependency-free BM25 implementation
- dense retrieval: `nomic-embed-text:v1.5` through the local Ollama embeddings API
- hybrid retrieval: reciprocal-rank fusion of the complete BM25 and dense rankings
- answer context: the top 4 hybrid records, selected before generation
- generation: `qwen2.5-coder:3b`, temperature 0, seed `20260720`, JSON schema, zero retries
- metrics: Recall@4, MRR@4, exact answer, abstention, citation precision/recall,
  grounding, schema validity, latency, and Ollama token counts
- deterministic release gate: expose an answer only when every answer, citation,
  abstention, and grounding check passes; otherwise retain and reject the raw output

Frozen inputs:

- `data/corpus.json`: SHA-256 `411464ce37a73534b2c715451b74fcd396e66b96cebcc8357af51088d80c8e43`
- `data/eval.json`: SHA-256 `938e2fd5e0778ca29e9b9ab3df1d1d96ac4ef07b9eeffa56065b4d1ef567d9ff`

The embedding model is documented in the
[official Ollama model registry](https://registry.ollama.com/library/nomic-embed-text).

## Run

Requirements: Python 3.11 or later, Ollama reachable at `127.0.0.1:11434`, and the two
exact model tags above installed locally.

```bash
python3 -m unittest discover -s tests -p 'test_*.py'
python3 src/run_benchmark.py --run-id run_01 --output-dir artifacts
python3 src/run_benchmark.py --run-id run_02 --output-dir artifacts
python3 src/verify_replay.py \
  --first artifacts/run_01.json \
  --second artifacts/run_02.json \
  --output artifacts/replay.json
python3 verify.py
```

See `artifacts/run_01_RESULTS.md` for measured results. Full per-question evidence is in
the JSON artifact.

## What this does not claim

This is an offline evaluation on a small synthetic English corpus. It does not test
multilingual retrieval, ingestion, a vector database, permissions, freshness,
multi-tenancy, agent orchestration, adversarial security, concurrency, production
traffic, provider billing, or an SLA. Local timings are observations from one sequential
run, not capacity claims.
