from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def main() -> None:
    completed = subprocess.run(
        [
            sys.executable,
            "-m",
            "unittest",
            "discover",
            "-s",
            str(ROOT / "tests"),
            "-p",
            "test_*.py",
        ],
        cwd=ROOT,
        check=False,
    )
    if completed.returncode != 0:
        raise SystemExit(completed.returncode)

    required_artifacts = [
        ROOT / "artifacts" / "run_01.json",
        ROOT / "artifacts" / "run_02.json",
        ROOT / "artifacts" / "replay.json",
    ]
    missing = [str(path) for path in required_artifacts if not path.is_file()]
    if missing:
        raise SystemExit(f"Required benchmark artifacts are missing: {missing}")
    first = json.loads(required_artifacts[0].read_text(encoding="utf-8"))
    second = json.loads(required_artifacts[1].read_text(encoding="utf-8"))
    replay = json.loads(required_artifacts[2].read_text(encoding="utf-8"))
    if not replay.get("exact_match"):
        raise SystemExit(f"Replay artifact is not an exact match: {replay}")
    if first["stable_projection_sha256"] != second["stable_projection_sha256"]:
        raise SystemExit(
            "Stable projection hashes differ: "
            f"{first['stable_projection_sha256']} != {second['stable_projection_sha256']}"
        )
    for label, run in (("run_01", first), ("run_02", second)):
        if run["answer_summary"]["valid_schema_rate"] < 1:
            raise SystemExit(f"{label} contains schema-invalid model output")
    print(
        "Project verification passed: tests=11, "
        f"replay_questions={replay['question_count']}, "
        f"stable_sha256={first['stable_projection_sha256']}"
    )


if __name__ == "__main__":
    main()
