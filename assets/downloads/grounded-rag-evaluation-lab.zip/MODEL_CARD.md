# Model and Evaluation Card

## Intended use

This lab demonstrates how to make a local RAG experiment inspectable: freeze the corpus
and questions, compare retrievers, constrain the answer context, validate output schema,
measure citations and abstention, and replay the same contract.

## Models

- Embeddings: `nomic-embed-text:v1.5`
- Answer generation: `qwen2.5-coder:3b`

Artifact metadata records the exact local model digests. Embedding inputs use the
`search_document:` and `search_query:` prefixes. Generation uses temperature 0, seed
`20260720`, a 4,096-token context limit, and at most 256 generated tokens.

## Data

All 24 records and 24 questions are synthetic and hand-authored for this project. They
contain no personal information, customer data, or copied company material. The corpus
and evaluation SHA-256 hashes were recorded before the first model benchmark.

## Success criteria

- report Recall@4 and MRR@4 independently for BM25, dense, and hybrid retrieval
- report exact answer, citation precision/recall, grounding, schema validity, and
  unanswerable abstention
- retain every raw answer and exact validation error
- reject, rather than replace, any output that fails the deterministic release contract
- perform zero retries
- reproduce retrieval IDs, raw answers, parsed outputs, and evaluation results in a
  second run under the same dataset and model digests

## Limitations

The benchmark is English-only, small, synthetic, single-hop, and offline. The
canonical-fact sentence format simplifies deterministic answer scoring. It does not
measure real enterprise document noise, multilingual behavior, long-context ingestion,
vector-store operations, access control, changing knowledge, prompt injection, model
security, concurrent load, or production reliability.
