# Grounded RAG Evaluation Results

Run: `run_02`

## Fixed contract

- Dataset: 24 synthetic English documents; 24 frozen questions (18 answerable, 6 unanswerable)
- Corpus SHA-256: `411464ce37a73534b2c715451b74fcd396e66b96cebcc8357af51088d80c8e43`
- Evaluation SHA-256: `938e2fd5e0778ca29e9b9ab3df1d1d96ac4ef07b9eeffa56065b4d1ef567d9ff`
- Retrieval: BM25 lexical, nomic-embed-text:v1.5 dense, and reciprocal-rank fusion with k=60
- Answering: hybrid top-4 only; qwen2.5-coder:3b; temperature 0; fixed seed; zero retries

## Retrieval

| Method | Recall@4 | MRR@4 | Misses |
|---|---:|---:|---:|
| lexical | 100.0% | 1.000 | 0 |
| dense | 100.0% | 1.000 | 0 |
| hybrid | 100.0% | 1.000 | 0 |

## Grounded answering

- Exact-answer accuracy: 79.2%
- Answerable exact accuracy: 83.3%
- Unanswerable abstention accuracy: 66.7%
- Citation precision / recall: 100.0% / 100.0%
- Grounded rate: 87.5%
- Schema-valid rate: 100.0%
- Failed questions: Q-008, Q-012, Q-017, Q-021, Q-022
- Failure counts: `{'abstention': 2, 'answer': 5, 'grounding': 3}`

## Deterministic release gate

The gate releases an answer only when schema, exact canonical sentence, citation, abstention, and grounding checks all pass. A rejected model output is retained as evidence and is not retried or replaced.

- Released answers / abstentions / rejected: 15 / 4 / 5
- Answerable release coverage: 83.3%
- Released-answer exact precision: 100.0%
- Unsupported answer releases: 0
- Answers blocked by the strict grounding proxy: 3 (Q-017, Q-021, Q-022)
- Answers released for unanswerable questions: 0

## Local execution measurements

- Generation calls: 24
- Wall latency p50 / p95: 867.8 ms / 957.8 ms
- Prompt / output tokens reported by Ollama: 10893 / 1001
- Stable projection SHA-256: `e917154a75729fb1987b5f04d7048516d512ea641830b45f7dbe418355d2982c`

These timings are sequential measurements on one local machine with uncontrolled process state. They are not cold-start, concurrency, production SLA, provider cost, or capacity claims.

## Boundaries

This experiment uses a small hand-authored English corpus. It does not evaluate multilingual retrieval, document ingestion, vector databases, access control, freshness, multi-tenancy, agent orchestration, security, or production traffic.
