# Grounded RAG Evaluation Results

Run: `run_01`

## Fixed contract

- Dataset: 24 synthetic English documents; 24 frozen questions (18 answerable, 6 unanswerable)
- Corpus SHA-256: `411464ce37a73534b2c715451b74fcd396e66b96cebcc8357af51088d80c8e43`
- Evaluation SHA-256: `938e2fd5e0778ca29e9b9ab3df1d1d96ac4ef07b9eeffa56065b4d1ef567d9ff`
- Retrieval: BM25 lexical, nomic-embed-text:v1.5 dense, and reciprocal-rank fusion with k=60
- Answering: hybrid top-4 only; qwen2.5-coder:3b; temperature 0; fixed seed; zero retries

## Retrieval

| Method | Recall@4 | MRR@4 | Misses |
|---|---:|---:|---:|
| lexical | 100.0% | 1.000 | 0 |
| dense | 100.0% | 1.000 | 0 |
| hybrid | 100.0% | 1.000 | 0 |

## Grounded answering

- Exact-answer accuracy: 79.2%
- Answerable exact accuracy: 83.3%
- Unanswerable abstention accuracy: 66.7%
- Citation precision / recall: 100.0% / 100.0%
- Grounded rate: 87.5%
- Schema-valid rate: 100.0%
- Failed questions: Q-008, Q-012, Q-017, Q-021, Q-022
- Failure counts: `{'abstention': 2, 'answer': 5, 'grounding': 3}`

## Local execution measurements

- Generation calls: 24
- Wall latency p50 / p95: 868.1 ms / 960.0 ms
- Prompt / output tokens reported by Ollama: 10893 / 1001
- Stable projection SHA-256: `e502e06f52935cfff7c0755334be75cf15117fa7026df1aa7d0a0fb0f4347b15`

These timings are sequential measurements on one local machine with uncontrolled process state. They are not cold-start, concurrency, production SLA, provider cost, or capacity claims.

## Boundaries

This experiment uses a small hand-authored English corpus. It does not evaluate multilingual retrieval, document ingestion, vector databases, access control, freshness, multi-tenancy, agent orchestration, security, or production traffic.
