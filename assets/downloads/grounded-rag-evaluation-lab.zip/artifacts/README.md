# Artifacts

`run_01.json` and `run_02.json` are full local benchmark records. Each stores frozen
dataset hashes, exact model digests, retrieval rankings, raw model responses, stage
metrics, token counts, and measured durations. `replay.json` compares their stable
projections while excluding timestamps and latency.

The generated `run_*_RESULTS.md` files are human-readable summaries of the same JSON.

`diagnostic_v1.json` is the preserved first ungated execution. Its raw behavior exposed
that schema validity alone did not prevent unsupported answers, so the canonical runs
add a deterministic release decision while keeping the dataset and prompt unchanged.
