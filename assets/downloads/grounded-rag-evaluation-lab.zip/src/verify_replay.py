from __future__ import annotations

import argparse
import json
from pathlib import Path

from rag_eval import verify_replay, write_json


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--first", required=True, type=Path)
    parser.add_argument("--second", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    first = json.loads(args.first.read_text(encoding="utf-8"))
    second = json.loads(args.second.read_text(encoding="utf-8"))
    result = verify_replay(first, second)
    write_json(args.output, result)
    if not result["exact_match"]:
        raise SystemExit(
            "Replay mismatch: "
            f"questions={result['mismatch_count']}, "
            f"metadata_equal={result['metadata_equal']}"
        )
    print(
        "Replay exact match: "
        f"questions={result['question_count']}, "
        f"sha256={result['first_stable_projection_sha256']}"
    )


if __name__ == "__main__":
    main()
