from __future__ import annotations

import argparse
from pathlib import Path

from rag_eval import run_experiment


ROOT = Path(__file__).resolve().parents[1]


def percentage(value: float) -> str:
    return f"{value * 100:.1f}%"


def write_report(path: Path, run: dict) -> None:
    retrieval = run["retrieval_summary"]
    answer = run["answer_summary"]
    gate = answer["release_gate"]
    generation = run["generation_summary"]
    top_k = run["configuration"]["top_k"]
    lines = [
        "# Grounded RAG Evaluation Results",
        "",
        f"Run: `{run['run_id']}`",
        "",
        "## Fixed contract",
        "",
        f"- Dataset: {run['dataset']['document_count']} synthetic English documents; "
        f"{run['dataset']['question_count']} frozen questions "
        f"({run['dataset']['answerable_question_count']} answerable, "
        f"{run['dataset']['unanswerable_question_count']} unanswerable)",
        f"- Corpus SHA-256: `{run['dataset']['corpus_sha256']}`",
        f"- Evaluation SHA-256: `{run['dataset']['eval_sha256']}`",
        f"- Retrieval: BM25 lexical, {run['configuration']['embedding_model']} dense, "
        f"and reciprocal-rank fusion with k={run['configuration']['rrf_rank_constant']}",
        f"- Answering: hybrid top-{top_k} only; {run['configuration']['generation_model']}; "
        "temperature 0; fixed seed; zero retries",
        "",
        "## Retrieval",
        "",
        f"| Method | Recall@{top_k} | MRR@{top_k} | Misses |",
        "|---|---:|---:|---:|",
    ]
    for method in ("lexical", "dense", "hybrid"):
        metrics = retrieval[method]
        lines.append(
            f"| {method} | {percentage(metrics[f'recall_at_{top_k}'])} | "
            f"{metrics[f'mrr_at_{top_k}']:.3f} | {metrics['miss_count']} |"
        )
    lines.extend(
        [
            "",
            "## Grounded answering",
            "",
            f"- Exact-answer accuracy: {percentage(answer['answer_exact_accuracy'])}",
            f"- Answerable exact accuracy: {percentage(answer['answerable_exact_accuracy'])}",
            f"- Unanswerable abstention accuracy: {percentage(answer['unanswerable_abstention_accuracy'])}",
            f"- Citation precision / recall: {percentage(answer['citation_precision'])} / "
            f"{percentage(answer['citation_recall'])}",
            f"- Grounded rate: {percentage(answer['grounded_rate'])}",
            f"- Schema-valid rate: {percentage(answer['valid_schema_rate'])}",
            f"- Failed questions: {', '.join(answer['failed_question_ids']) or 'none'}",
            f"- Failure counts: `{answer['failure_counts']}`",
            "",
            "## Deterministic release gate",
            "",
            "The gate releases an answer only when schema, exact canonical sentence, "
            "citation, abstention, and grounding checks all pass. A rejected model output "
            "is retained as evidence and is not retried or replaced.",
            "",
            f"- Released answers / abstentions / rejected: "
            f"{gate['released_answer_count']} / {gate['released_abstention_count']} / "
            f"{gate['rejected_count']}",
            f"- Answerable release coverage: {percentage(gate['answerable_release_coverage'])}",
            f"- Released-answer exact precision: "
            f"{percentage(gate['released_answer_exact_precision'])}",
            f"- Unsupported answer releases: {gate['unsupported_answer_release_count']}",
            f"- Answers blocked by the strict grounding proxy: "
            f"{gate['blocked_non_grounded_answer_count']} "
            f"({', '.join(gate['blocked_non_grounded_question_ids']) or 'none'})",
            f"- Answers released for unanswerable questions: "
            f"{gate['unanswerable_answer_release_count']}",
            "",
            "## Local execution measurements",
            "",
            f"- Generation calls: {generation['call_count']}",
            f"- Wall latency p50 / p95: {generation['wall_duration']['p50_ms']:.1f} ms / "
            f"{generation['wall_duration']['p95_ms']:.1f} ms",
            f"- Prompt / output tokens reported by Ollama: "
            f"{generation['prompt_eval_count']} / {generation['eval_count']}",
            f"- Stable projection SHA-256: `{run['stable_projection_sha256']}`",
            "",
            "These timings are sequential measurements on one local machine with uncontrolled "
            "process state. They are not cold-start, concurrency, production SLA, provider cost, "
            "or capacity claims.",
            "",
            "## Boundaries",
            "",
            "This experiment uses a small hand-authored English corpus. It does not evaluate "
            "multilingual retrieval, document ingestion, vector databases, access control, "
            "freshness, multi-tenancy, agent orchestration, security, or production traffic.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    run_path = args.output_dir / f"{args.run_id}.json"
    run = run_experiment(
        corpus_path=ROOT / "data" / "corpus.json",
        eval_path=ROOT / "data" / "eval.json",
        output_path=run_path,
        source_paths=[Path(__file__), ROOT / "src" / "rag_eval.py"],
        run_id=args.run_id,
    )
    write_report(args.output_dir / f"{args.run_id}_RESULTS.md", run)
    answer = run["answer_summary"]
    hybrid = run["retrieval_summary"]["hybrid"]
    top_k = run["configuration"]["top_k"]
    print(
        "Grounded RAG benchmark completed: "
        f"hybrid_recall@{top_k}={hybrid[f'recall_at_{top_k}']:.3f}, "
        f"answer_exact={answer['answer_exact_accuracy']:.3f}, "
        f"abstention={answer['unanswerable_abstention_accuracy']:.3f}, "
        f"stable_sha256={run['stable_projection_sha256']}"
    )


if __name__ == "__main__":
    main()
