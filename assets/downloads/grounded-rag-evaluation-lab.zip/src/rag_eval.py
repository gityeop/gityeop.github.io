from __future__ import annotations

import hashlib
import json
import math
import platform
import re
import statistics
import sys
import time
import urllib.error
import urllib.request
from collections import Counter
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence


OLLAMA_URL = "http://127.0.0.1:11434"
EMBEDDING_MODEL = "nomic-embed-text:v1.5"
GENERATION_MODEL = "qwen2.5-coder:3b"
SEED = 20260720
TOP_K = 4
RRF_K = 60
INSUFFICIENT_EVIDENCE = "INSUFFICIENT_EVIDENCE"


@dataclass(frozen=True)
class Document:
    id: str
    title: str
    text: str


@dataclass(frozen=True)
class EvalCase:
    id: str
    query: str
    answerable: bool
    expected_answer: str
    relevant_ids: list[str]


@dataclass(frozen=True)
class SearchHit:
    doc_id: str
    score: float


@dataclass(frozen=True)
class Embedding:
    vector: list[float]
    wall_duration_ms: float


@dataclass(frozen=True)
class Generation:
    response: str
    model: str
    wall_duration_ms: float
    total_duration_ms: float
    load_duration_ms: float
    prompt_eval_count: int
    eval_count: int


@dataclass(frozen=True)
class ParsedAnswer:
    answer: str
    citations: list[str]
    abstain: bool


TOKEN_RE = re.compile(r"[a-z0-9]+")


def tokenize(text: str) -> list[str]:
    return TOKEN_RE.findall(text.casefold())


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def stable_json_sha256(value: Any) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            value,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )


def _require_exact_keys(payload: dict[str, Any], keys: set[str], label: str) -> None:
    actual = set(payload)
    if actual != keys:
        raise ValueError(
            f"{label} keys must be exactly {sorted(keys)}, got {sorted(actual)}"
        )


def load_dataset(corpus_path: Path, eval_path: Path) -> tuple[list[Document], list[EvalCase]]:
    corpus_payload = json.loads(corpus_path.read_text(encoding="utf-8"))
    if not isinstance(corpus_payload, dict):
        raise ValueError("Corpus root must be a JSON object")
    _require_exact_keys(
        corpus_payload,
        {"version", "language", "domain", "documents"},
        "Corpus",
    )
    if corpus_payload["language"] != "en":
        raise ValueError(f"Corpus language must be en, got {corpus_payload['language']!r}")
    raw_documents = corpus_payload["documents"]
    if not isinstance(raw_documents, list) or not raw_documents:
        raise ValueError("Corpus documents must be a non-empty list")
    documents: list[Document] = []
    for index, item in enumerate(raw_documents):
        if not isinstance(item, dict):
            raise ValueError(f"Document {index} must be a JSON object")
        _require_exact_keys(item, {"id", "title", "text"}, f"Document {index}")
        document = Document(**item)
        if not document.id or not document.title or not document.text:
            raise ValueError(f"Document {index} contains an empty field")
        if document.text.count("Canonical fact:") != 1:
            raise ValueError(
                f"Document {document.id} must contain exactly one Canonical fact marker"
            )
        documents.append(document)
    document_ids = [document.id for document in documents]
    if len(document_ids) != len(set(document_ids)):
        raise ValueError("Document ids must be unique")

    eval_payload = json.loads(eval_path.read_text(encoding="utf-8"))
    if not isinstance(eval_payload, dict):
        raise ValueError("Evaluation root must be a JSON object")
    _require_exact_keys(
        eval_payload,
        {"version", "language", "frozen_before_first_run", "questions"},
        "Evaluation",
    )
    if eval_payload["language"] != "en":
        raise ValueError(f"Evaluation language must be en, got {eval_payload['language']!r}")
    if eval_payload["frozen_before_first_run"] is not True:
        raise ValueError("Evaluation must declare frozen_before_first_run=true")
    raw_cases = eval_payload["questions"]
    if not isinstance(raw_cases, list) or not raw_cases:
        raise ValueError("Evaluation questions must be a non-empty list")
    cases: list[EvalCase] = []
    known_document_ids = set(document_ids)
    document_text_by_id = {document.id: document.text for document in documents}
    for index, item in enumerate(raw_cases):
        if not isinstance(item, dict):
            raise ValueError(f"Question {index} must be a JSON object")
        _require_exact_keys(
            item,
            {"id", "query", "answerable", "expected_answer", "relevant_ids"},
            f"Question {index}",
        )
        case = EvalCase(**item)
        if type(case.answerable) is not bool:
            raise ValueError(f"Question {case.id} answerable must be a boolean")
        if not isinstance(case.relevant_ids, list) or any(
            not isinstance(item, str) for item in case.relevant_ids
        ):
            raise ValueError(f"Question {case.id} relevant_ids must be a list of strings")
        if len(case.relevant_ids) != len(set(case.relevant_ids)):
            raise ValueError(f"Question {case.id} relevant_ids must be unique")
        unknown_ids = sorted(set(case.relevant_ids) - known_document_ids)
        if unknown_ids:
            raise ValueError(f"Question {case.id} references unknown documents: {unknown_ids}")
        if case.answerable:
            if not case.relevant_ids:
                raise ValueError(f"Answerable question {case.id} requires relevant_ids")
            if case.expected_answer == INSUFFICIENT_EVIDENCE:
                raise ValueError(f"Answerable question {case.id} has abstention answer")
            if not any(
                case.expected_answer in document_text_by_id[doc_id]
                for doc_id in case.relevant_ids
            ):
                raise ValueError(
                    f"Expected answer for {case.id} does not occur in a relevant document"
                )
        else:
            if case.relevant_ids:
                raise ValueError(f"Unanswerable question {case.id} must not have relevant_ids")
            if case.expected_answer != INSUFFICIENT_EVIDENCE:
                raise ValueError(
                    f"Unanswerable question {case.id} must use {INSUFFICIENT_EVIDENCE}"
                )
        cases.append(case)
    case_ids = [case.id for case in cases]
    if len(case_ids) != len(set(case_ids)):
        raise ValueError("Question ids must be unique")
    return documents, cases


class BM25Index:
    def __init__(
        self,
        documents: Sequence[Document],
        k1: float = 1.5,
        b: float = 0.75,
    ) -> None:
        if not documents:
            raise ValueError("BM25 requires at least one document")
        self.documents = list(documents)
        self.k1 = k1
        self.b = b
        self.term_frequencies = [
            Counter(tokenize(f"{document.title} {document.text}"))
            for document in documents
        ]
        self.lengths = [sum(frequencies.values()) for frequencies in self.term_frequencies]
        self.average_length = statistics.fmean(self.lengths)
        document_frequency: Counter[str] = Counter()
        for frequencies in self.term_frequencies:
            document_frequency.update(frequencies.keys())
        size = len(documents)
        self.idf = {
            term: math.log(1 + (size - frequency + 0.5) / (frequency + 0.5))
            for term, frequency in document_frequency.items()
        }

    def search(self, query: str, top_k: int) -> list[SearchHit]:
        if top_k <= 0:
            raise ValueError(f"top_k must be positive, got {top_k}")
        query_terms = tokenize(query)
        scored: list[SearchHit] = []
        for document, frequencies, length in zip(
            self.documents,
            self.term_frequencies,
            self.lengths,
            strict=True,
        ):
            score = 0.0
            normalization = self.k1 * (
                1 - self.b + self.b * length / self.average_length
            )
            for term in query_terms:
                frequency = frequencies.get(term, 0)
                if frequency == 0:
                    continue
                score += self.idf[term] * (
                    frequency * (self.k1 + 1) / (frequency + normalization)
                )
            scored.append(SearchHit(document.id, score))
        return sorted(scored, key=lambda hit: (-hit.score, hit.doc_id))[:top_k]


def cosine_similarity(left: Sequence[float], right: Sequence[float]) -> float:
    if len(left) != len(right):
        raise ValueError(
            f"Embedding dimension mismatch: left={len(left)}, right={len(right)}"
        )
    if not left:
        raise ValueError("Embeddings must not be empty")
    left_norm = math.sqrt(sum(value * value for value in left))
    right_norm = math.sqrt(sum(value * value for value in right))
    if left_norm == 0 or right_norm == 0:
        raise ValueError("Embeddings must have non-zero magnitude")
    return sum(a * b for a, b in zip(left, right, strict=True)) / (
        left_norm * right_norm
    )


def dense_search(
    query_vector: Sequence[float],
    documents: Sequence[Document],
    document_vectors: dict[str, Sequence[float]],
    top_k: int,
) -> list[SearchHit]:
    if top_k <= 0:
        raise ValueError(f"top_k must be positive, got {top_k}")
    expected_ids = {document.id for document in documents}
    if set(document_vectors) != expected_ids:
        raise ValueError("Dense index ids do not match corpus ids")
    hits = [
        SearchHit(document.id, cosine_similarity(query_vector, document_vectors[document.id]))
        for document in documents
    ]
    return sorted(hits, key=lambda hit: (-hit.score, hit.doc_id))[:top_k]


def reciprocal_rank_fusion(
    rankings: Sequence[Sequence[SearchHit]],
    top_k: int,
    rank_constant: int = RRF_K,
) -> list[SearchHit]:
    if len(rankings) < 2:
        raise ValueError("Reciprocal-rank fusion requires at least two rankings")
    if top_k <= 0:
        raise ValueError(f"top_k must be positive, got {top_k}")
    if rank_constant <= 0:
        raise ValueError(f"rank_constant must be positive, got {rank_constant}")
    scores: dict[str, float] = {}
    for ranking_index, ranking in enumerate(rankings):
        ids = [hit.doc_id for hit in ranking]
        if len(ids) != len(set(ids)):
            raise ValueError(f"Ranking {ranking_index} contains duplicate document ids")
        for rank, hit in enumerate(ranking, start=1):
            scores[hit.doc_id] = scores.get(hit.doc_id, 0.0) + 1 / (
                rank_constant + rank
            )
    hits = [SearchHit(doc_id, score) for doc_id, score in scores.items()]
    return sorted(hits, key=lambda hit: (-hit.score, hit.doc_id))[:top_k]


def retrieval_metrics(
    cases: Sequence[EvalCase],
    rankings: dict[str, Sequence[SearchHit]],
    top_k: int,
) -> dict[str, Any]:
    answerable_cases = [case for case in cases if case.answerable]
    if not answerable_cases:
        raise ValueError("Retrieval evaluation requires answerable questions")
    recalls: list[float] = []
    reciprocal_ranks: list[float] = []
    misses: list[str] = []
    for case in answerable_cases:
        ranking = rankings[case.id]
        top_ids = [hit.doc_id for hit in ranking[:top_k]]
        relevant = set(case.relevant_ids)
        recall = len(relevant.intersection(top_ids)) / len(relevant)
        recalls.append(recall)
        first_rank = next(
            (rank for rank, doc_id in enumerate(top_ids, start=1) if doc_id in relevant),
            None,
        )
        reciprocal_ranks.append(0.0 if first_rank is None else 1 / first_rank)
        if recall < 1:
            misses.append(case.id)
    return {
        "answerable_question_count": len(answerable_cases),
        f"recall_at_{top_k}": statistics.fmean(recalls),
        f"mrr_at_{top_k}": statistics.fmean(reciprocal_ranks),
        "miss_count": len(misses),
        "miss_question_ids": misses,
    }


def build_answer_prompt(
    query: str,
    retrieved_documents: Sequence[Document],
) -> str:
    records = "\n\n".join(
        f"RECORD {rank}\nID: {document.id}\nTITLE: {document.title}\nTEXT: {document.text}"
        for rank, document in enumerate(retrieved_documents, start=1)
    )
    return (
        "Answer one question using only the records below.\n"
        "Return a JSON object with exactly these keys: answer, citations, abstain.\n"
        "Rules:\n"
        f"- If one record explicitly answers the question, copy that record's complete sentence immediately after 'Canonical fact:' into answer.\n"
        "- citations must contain only the ID of each record needed for that copied answer.\n"
        "- Do not cite merely related records. Do not combine or infer unstated facts.\n"
        f"- If the records do not explicitly answer the question, set answer to '{INSUFFICIENT_EVIDENCE}', citations to [], and abstain to true.\n"
        "- Otherwise set abstain to false.\n\n"
        f"QUESTION: {query}\n\n"
        f"{records}"
    )


def parse_answer(raw_response: str, retrieved_ids: Iterable[str]) -> ParsedAnswer:
    try:
        payload = json.loads(raw_response)
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"JSONDecodeError: {exc.msg} at line {exc.lineno} column {exc.colno}"
        ) from None
    if not isinstance(payload, dict):
        raise ValueError(f"Response must be a JSON object, got {type(payload).__name__}")
    _require_exact_keys(payload, {"answer", "citations", "abstain"}, "Response")
    answer = payload["answer"]
    citations = payload["citations"]
    abstain = payload["abstain"]
    if not isinstance(answer, str) or not answer.strip():
        raise ValueError("answer must be a non-empty string")
    if not isinstance(citations, list) or any(
        not isinstance(citation, str) for citation in citations
    ):
        raise ValueError("citations must be a list of strings")
    if len(citations) != len(set(citations)):
        raise ValueError("citations must not contain duplicates")
    if type(abstain) is not bool:
        raise ValueError("abstain must be a boolean")
    unknown_citations = sorted(set(citations) - set(retrieved_ids))
    if unknown_citations:
        raise ValueError(f"citations not present in retrieved context: {unknown_citations}")
    if abstain:
        if answer != INSUFFICIENT_EVIDENCE or citations:
            raise ValueError(
                "abstain=true requires answer=INSUFFICIENT_EVIDENCE and citations=[]"
            )
    elif answer == INSUFFICIENT_EVIDENCE:
        raise ValueError("abstain=false cannot use INSUFFICIENT_EVIDENCE")
    return ParsedAnswer(answer=answer, citations=citations, abstain=abstain)


def normalize_answer(answer: str) -> str:
    return " ".join(answer.casefold().split())


def evaluate_answer(
    case: EvalCase,
    parsed: ParsedAnswer | None,
    documents_by_id: dict[str, Document],
    validation_error: str | None,
) -> dict[str, Any]:
    if (parsed is None) == (validation_error is None):
        raise ValueError("Exactly one of parsed or validation_error must be present")
    if parsed is None:
        return {
            "valid_schema": False,
            "answer_exact": False,
            "abstention_correct": False,
            "citation_precision": 0.0 if case.answerable else None,
            "citation_recall": 0.0 if case.answerable else None,
            "grounded": False,
            "failure_types": ["schema"],
            "release_decision": "reject",
            "release_reason": f"schema: {validation_error}",
        }

    answer_exact = normalize_answer(parsed.answer) == normalize_answer(case.expected_answer)
    abstention_correct = parsed.abstain == (not case.answerable)
    failure_types: list[str] = []
    if not answer_exact:
        failure_types.append("answer")
    if not abstention_correct:
        failure_types.append("abstention")

    if case.answerable:
        cited = set(parsed.citations)
        relevant = set(case.relevant_ids)
        citation_precision = len(cited.intersection(relevant)) / len(cited) if cited else 0.0
        citation_recall = len(cited.intersection(relevant)) / len(relevant)
        if citation_precision < 1 or citation_recall < 1:
            failure_types.append("citation")
        cited_text = " ".join(documents_by_id[doc_id].text for doc_id in parsed.citations)
        grounded = bool(parsed.citations) and parsed.answer in cited_text
    else:
        citation_precision = None
        citation_recall = None
        grounded = (
            parsed.abstain
            and parsed.answer == INSUFFICIENT_EVIDENCE
            and not parsed.citations
        )
    if not grounded:
        failure_types.append("grounding")
    if failure_types:
        release_decision = "reject"
        release_reason = f"contract_failure: {','.join(failure_types)}"
    elif parsed.abstain:
        release_decision = "release_abstention"
        release_reason = "contract_passed"
    else:
        release_decision = "release_answer"
        release_reason = "contract_passed"
    return {
        "valid_schema": True,
        "answer_exact": answer_exact,
        "abstention_correct": abstention_correct,
        "citation_precision": citation_precision,
        "citation_recall": citation_recall,
        "grounded": grounded,
        "failure_types": failure_types,
        "release_decision": release_decision,
        "release_reason": release_reason,
    }


def aggregate_answer_metrics(case_results: Sequence[dict[str, Any]]) -> dict[str, Any]:
    if not case_results:
        raise ValueError("Answer evaluation requires at least one result")
    answerable = [result for result in case_results if result["answerable"]]
    unanswerable = [result for result in case_results if not result["answerable"]]
    evaluations = [result["evaluation"] for result in case_results]
    answerable_evaluations = [result["evaluation"] for result in answerable]
    unanswerable_evaluations = [result["evaluation"] for result in unanswerable]
    failure_counts: Counter[str] = Counter(
        failure
        for evaluation in evaluations
        for failure in evaluation["failure_types"]
    )
    released_answers = [
        result
        for result in case_results
        if result["evaluation"]["release_decision"] == "release_answer"
    ]
    released_abstentions = [
        result
        for result in case_results
        if result["evaluation"]["release_decision"] == "release_abstention"
    ]
    rejected = [
        result
        for result in case_results
        if result["evaluation"]["release_decision"] == "reject"
    ]
    if not released_answers:
        raise ValueError("Release-gate evaluation produced no released answers")
    unsupported_releases = [
        result
        for result in released_answers
        if not result["evaluation"]["grounded"]
    ]
    blocked_non_grounded_answers = [
        result
        for result in rejected
        if result["parsed_answer"] is not None
        and not result["parsed_answer"]["abstain"]
        and not result["evaluation"]["grounded"]
    ]
    return {
        "question_count": len(case_results),
        "answerable_question_count": len(answerable),
        "unanswerable_question_count": len(unanswerable),
        "valid_schema_rate": statistics.fmean(
            evaluation["valid_schema"] for evaluation in evaluations
        ),
        "answer_exact_accuracy": statistics.fmean(
            evaluation["answer_exact"] for evaluation in evaluations
        ),
        "answerable_exact_accuracy": statistics.fmean(
            evaluation["answer_exact"] for evaluation in answerable_evaluations
        ),
        "unanswerable_abstention_accuracy": statistics.fmean(
            evaluation["abstention_correct"] for evaluation in unanswerable_evaluations
        ),
        "overall_abstention_accuracy": statistics.fmean(
            evaluation["abstention_correct"] for evaluation in evaluations
        ),
        "citation_precision": statistics.fmean(
            evaluation["citation_precision"] for evaluation in answerable_evaluations
        ),
        "citation_recall": statistics.fmean(
            evaluation["citation_recall"] for evaluation in answerable_evaluations
        ),
        "grounded_rate": statistics.fmean(
            evaluation["grounded"] for evaluation in evaluations
        ),
        "failure_counts": dict(sorted(failure_counts.items())),
        "failed_question_ids": [
            result["id"]
            for result in case_results
            if result["evaluation"]["failure_types"]
        ],
        "release_gate": {
            "released_answer_count": len(released_answers),
            "released_abstention_count": len(released_abstentions),
            "rejected_count": len(rejected),
            "rejected_question_ids": [result["id"] for result in rejected],
            "answerable_release_coverage": len(released_answers) / len(answerable),
            "released_answer_exact_precision": statistics.fmean(
                result["evaluation"]["answer_exact"] for result in released_answers
            ),
            "unsupported_answer_release_count": len(unsupported_releases),
            "blocked_non_grounded_answer_count": len(blocked_non_grounded_answers),
            "blocked_non_grounded_question_ids": [
                result["id"] for result in blocked_non_grounded_answers
            ],
            "unanswerable_answer_release_count": sum(
                not result["answerable"] for result in released_answers
            ),
        },
    }


def percentile(values: Sequence[float], probability: float) -> float:
    if not values:
        raise ValueError("Percentile requires at least one value")
    if not 0 <= probability <= 1:
        raise ValueError(f"Probability must be in [0, 1], got {probability}")
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return float(ordered[lower])
    weight = position - lower
    return ordered[lower] * (1 - weight) + ordered[upper] * weight


def duration_summary(values: Sequence[float]) -> dict[str, float]:
    return {
        "count": len(values),
        "mean_ms": statistics.fmean(values),
        "p50_ms": percentile(values, 0.5),
        "p95_ms": percentile(values, 0.95),
        "max_ms": max(values),
    }


class OllamaClient:
    def __init__(self, base_url: str = OLLAMA_URL) -> None:
        self.base_url = base_url.rstrip("/")

    def _get_json(self, path: str) -> dict[str, Any]:
        request = urllib.request.Request(f"{self.base_url}{path}", method="GET")
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                raw = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Ollama HTTP {exc.code}: {detail}") from None
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Ollama request failed: {exc.reason}") from None
        payload = json.loads(raw)
        if not isinstance(payload, dict):
            raise RuntimeError("Ollama response must be a JSON object")
        return payload

    def _post_json(self, path: str, body: dict[str, Any], timeout: int) -> dict[str, Any]:
        request = urllib.request.Request(
            f"{self.base_url}{path}",
            data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                raw = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Ollama HTTP {exc.code}: {detail}") from None
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Ollama request failed: {exc.reason}") from None
        payload = json.loads(raw)
        if not isinstance(payload, dict):
            raise RuntimeError("Ollama response must be a JSON object")
        return payload

    def model_info(self, model: str) -> dict[str, Any]:
        payload = self._get_json("/api/tags")
        models = payload.get("models")
        if not isinstance(models, list):
            raise RuntimeError("Ollama tags response missing models list")
        matches = [item for item in models if item.get("name") == model]
        if len(matches) != 1:
            available = sorted(
                item.get("name", "<missing-name>")
                for item in models
                if isinstance(item, dict)
            )
            raise RuntimeError(
                f"Expected exactly one Ollama model named {model}, found {len(matches)}; "
                f"available={available}"
            )
        item = matches[0]
        required = {"name", "digest", "size", "modified_at"}
        missing = sorted(required - set(item))
        if missing:
            raise RuntimeError(f"Ollama model metadata missing fields: {missing}")
        return {
            "name": item["name"],
            "digest": item["digest"],
            "size_bytes": item["size"],
            "modified_at": item["modified_at"],
        }

    def embed(self, prompt: str, model: str = EMBEDDING_MODEL) -> Embedding:
        started = time.perf_counter()
        payload = self._post_json(
            "/api/embeddings",
            {"model": model, "prompt": prompt},
            timeout=120,
        )
        wall_duration_ms = (time.perf_counter() - started) * 1000
        vector = payload.get("embedding")
        if not isinstance(vector, list) or not vector:
            raise RuntimeError("Ollama embeddings response missing non-empty embedding")
        if any(type(value) not in {float, int} for value in vector):
            raise RuntimeError("Ollama embedding contains a non-numeric value")
        return Embedding(
            vector=[float(value) for value in vector],
            wall_duration_ms=wall_duration_ms,
        )

    def generate(self, prompt: str, model: str = GENERATION_MODEL) -> Generation:
        body = {
            "model": model,
            "prompt": prompt,
            "stream": False,
            "format": "json",
            "options": {
                "temperature": 0,
                "seed": SEED,
                "num_ctx": 4096,
                "num_predict": 256,
            },
            "keep_alive": "30m",
        }
        started = time.perf_counter()
        payload = self._post_json("/api/generate", body, timeout=120)
        wall_duration_ms = (time.perf_counter() - started) * 1000
        required = {
            "model",
            "response",
            "total_duration",
            "load_duration",
            "prompt_eval_count",
            "eval_count",
        }
        missing = sorted(required - set(payload))
        if missing:
            raise RuntimeError(f"Ollama generation response missing fields: {missing}")
        if payload["model"] != model:
            raise RuntimeError(
                f"Ollama model mismatch: expected {model}, got {payload['model']}"
            )
        return Generation(
            response=payload["response"],
            model=payload["model"],
            wall_duration_ms=wall_duration_ms,
            total_duration_ms=payload["total_duration"] / 1_000_000,
            load_duration_ms=payload["load_duration"] / 1_000_000,
            prompt_eval_count=int(payload["prompt_eval_count"]),
            eval_count=int(payload["eval_count"]),
        )


def _hits_to_dicts(hits: Sequence[SearchHit]) -> list[dict[str, Any]]:
    return [asdict(hit) for hit in hits]


def _stable_projection(run: dict[str, Any]) -> dict[str, Any]:
    return {
        "dataset": run["dataset"],
        "configuration": run["configuration"],
        "models": run["models"],
        "retrieval_summary": run["retrieval_summary"],
        "answer_summary": run["answer_summary"],
        "cases": [
            {
                "id": result["id"],
                "ranked_ids": {
                    method: [hit["doc_id"] for hit in result["rankings"][method]]
                    for method in ("lexical", "dense", "hybrid")
                },
                "raw_response": result["generation"]["response"],
                "parsed_answer": result["parsed_answer"],
                "released_output": result["released_output"],
                "validation_error": result["validation_error"],
                "evaluation": result["evaluation"],
            }
            for result in run["cases"]
        ],
    }


def run_experiment(
    corpus_path: Path,
    eval_path: Path,
    output_path: Path,
    source_paths: Sequence[Path],
    run_id: str,
    client: OllamaClient | None = None,
) -> dict[str, Any]:
    started_at = datetime.now(timezone.utc).isoformat()
    documents, cases = load_dataset(corpus_path, eval_path)
    documents_by_id = {document.id: document for document in documents}
    client = client or OllamaClient()
    model_info = {
        "embedding": client.model_info(EMBEDDING_MODEL),
        "generation": client.model_info(GENERATION_MODEL),
    }

    document_vectors: dict[str, list[float]] = {}
    document_embedding_durations: list[float] = []
    for document in documents:
        embedding = client.embed(
            f"search_document: {document.title}\n{document.text}",
            model=EMBEDDING_MODEL,
        )
        document_vectors[document.id] = embedding.vector
        document_embedding_durations.append(embedding.wall_duration_ms)
    dimensions = {len(vector) for vector in document_vectors.values()}
    if len(dimensions) != 1:
        raise RuntimeError(f"Document embedding dimensions are inconsistent: {dimensions}")
    embedding_dimension = next(iter(dimensions))

    bm25 = BM25Index(documents)
    full_count = len(documents)
    all_rankings: dict[str, dict[str, list[SearchHit]]] = {
        "lexical": {},
        "dense": {},
        "hybrid": {},
    }
    query_embedding_durations: list[float] = []
    query_vectors: dict[str, list[float]] = {}
    for case in cases:
        embedding = client.embed(f"search_query: {case.query}", model=EMBEDDING_MODEL)
        if len(embedding.vector) != embedding_dimension:
            raise RuntimeError(
                f"Query {case.id} embedding dimension {len(embedding.vector)} does not "
                f"match document dimension {embedding_dimension}"
            )
        query_vectors[case.id] = embedding.vector
        query_embedding_durations.append(embedding.wall_duration_ms)
        lexical = bm25.search(case.query, full_count)
        dense = dense_search(
            embedding.vector,
            documents,
            document_vectors,
            full_count,
        )
        hybrid = reciprocal_rank_fusion([lexical, dense], full_count, RRF_K)
        all_rankings["lexical"][case.id] = lexical
        all_rankings["dense"][case.id] = dense
        all_rankings["hybrid"][case.id] = hybrid

    retrieval_summary = {
        method: retrieval_metrics(cases, rankings, TOP_K)
        for method, rankings in all_rankings.items()
    }

    case_results: list[dict[str, Any]] = []
    generation_wall_durations: list[float] = []
    generation_total_durations: list[float] = []
    prompt_tokens = 0
    output_tokens = 0
    for case in cases:
        hybrid_hits = all_rankings["hybrid"][case.id][:TOP_K]
        retrieved_documents = [documents_by_id[hit.doc_id] for hit in hybrid_hits]
        prompt = build_answer_prompt(case.query, retrieved_documents)
        generation = client.generate(prompt, model=GENERATION_MODEL)
        generation_wall_durations.append(generation.wall_duration_ms)
        generation_total_durations.append(generation.total_duration_ms)
        prompt_tokens += generation.prompt_eval_count
        output_tokens += generation.eval_count
        parsed: ParsedAnswer | None = None
        validation_error: str | None = None
        try:
            parsed = parse_answer(
                generation.response,
                [document.id for document in retrieved_documents],
            )
        except ValueError as exc:
            validation_error = str(exc)
        evaluation = evaluate_answer(
            case,
            parsed,
            documents_by_id,
            validation_error,
        )
        case_results.append(
            {
                "id": case.id,
                "query": case.query,
                "answerable": case.answerable,
                "expected_answer": case.expected_answer,
                "relevant_ids": case.relevant_ids,
                "rankings": {
                    method: _hits_to_dicts(all_rankings[method][case.id][:TOP_K])
                    for method in ("lexical", "dense", "hybrid")
                },
                "prompt_sha256": hashlib.sha256(prompt.encode("utf-8")).hexdigest(),
                "generation": asdict(generation),
                "parsed_answer": None if parsed is None else asdict(parsed),
                "released_output": (
                    None
                    if evaluation["release_decision"] == "reject"
                    else asdict(parsed)
                ),
                "validation_error": validation_error,
                "evaluation": evaluation,
            }
        )

    answer_summary = aggregate_answer_metrics(case_results)
    run: dict[str, Any] = {
        "schema_version": "1.0.0",
        "run_id": run_id,
        "started_at_utc": started_at,
        "environment": {
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "ollama_url": OLLAMA_URL,
            "execution": "local sequential; no concurrency or production traffic",
        },
        "dataset": {
            "corpus_path": str(corpus_path.resolve()),
            "corpus_sha256": sha256_file(corpus_path),
            "eval_path": str(eval_path.resolve()),
            "eval_sha256": sha256_file(eval_path),
            "document_count": len(documents),
            "question_count": len(cases),
            "answerable_question_count": sum(case.answerable for case in cases),
            "unanswerable_question_count": sum(not case.answerable for case in cases),
            "language": "en",
            "synthetic": True,
        },
        "configuration": {
            "embedding_model": EMBEDDING_MODEL,
            "generation_model": GENERATION_MODEL,
            "embedding_document_prefix": "search_document:",
            "embedding_query_prefix": "search_query:",
            "top_k": TOP_K,
            "rrf_rank_constant": RRF_K,
            "seed": SEED,
            "temperature": 0,
            "retrieval_methods": ["lexical", "dense", "hybrid"],
            "answer_retriever": "hybrid fixed before execution",
            "retry_count": 0,
        },
        "models": model_info,
        "source_sha256": {
            str(path.resolve()): sha256_file(path) for path in source_paths
        },
        "embedding_summary": {
            "dimension": embedding_dimension,
            "document_calls": duration_summary(document_embedding_durations),
            "query_calls": duration_summary(query_embedding_durations),
        },
        "retrieval_summary": retrieval_summary,
        "answer_summary": answer_summary,
        "generation_summary": {
            "call_count": len(cases),
            "wall_duration": duration_summary(generation_wall_durations),
            "ollama_total_duration": duration_summary(generation_total_durations),
            "prompt_eval_count": prompt_tokens,
            "eval_count": output_tokens,
        },
        "cases": case_results,
    }
    run["stable_projection_sha256"] = stable_json_sha256(_stable_projection(run))
    write_json(output_path, run)
    return run


def verify_replay(first: dict[str, Any], second: dict[str, Any]) -> dict[str, Any]:
    first_projection = _stable_projection(first)
    second_projection = _stable_projection(second)
    mismatches: list[dict[str, Any]] = []
    first_cases = {case["id"]: case for case in first_projection["cases"]}
    second_cases = {case["id"]: case for case in second_projection["cases"]}
    for case_id in sorted(set(first_cases) | set(second_cases)):
        if first_cases.get(case_id) != second_cases.get(case_id):
            mismatches.append(
                {
                    "question_id": case_id,
                    "first": first_cases.get(case_id),
                    "second": second_cases.get(case_id),
                }
            )
    metadata_equal = {
        field: first_projection[field] == second_projection[field]
        for field in (
            "dataset",
            "configuration",
            "models",
            "retrieval_summary",
            "answer_summary",
        )
    }
    exact = not mismatches and all(metadata_equal.values())
    return {
        "exact_match": exact,
        "question_count": len(first_cases),
        "mismatch_count": len(mismatches),
        "metadata_equal": metadata_equal,
        "first_stable_projection_sha256": stable_json_sha256(first_projection),
        "second_stable_projection_sha256": stable_json_sha256(second_projection),
        "mismatches": mismatches,
    }
